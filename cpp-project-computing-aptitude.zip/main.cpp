#include <iostream>
#include <unordered_map>
#include <vector>
#include <queue>
#include <string>
#include <map>
#include <set>
using namespace std;

// Structure to store movie information
struct Movie {
    string title;
    double rating;     // Average rating of the movie
    int totalRatings;  // Number of users who rated the movie
    set<string> genres;

    // Constructor
    Movie(string t, double r, int tr, set<string> g) : title(t), rating(r), totalRatings(tr), genres(g) {}

    // Update movie rating
    void updateRating(double newRating) {
        rating = (rating * totalRatings + newRating) / (totalRatings + 1);
        totalRatings++;
    }
};

// Priority queue comparator (for recommending the highest-rated movies)
struct MovieComparator {
    bool operator()(Movie* m1, Movie* m2) {
        return m1->rating < m2->rating;  // Max-heap based on rating
    }
};

// User structure representing their preferences and watch history
struct User {
    string name;
    set<string> likedMovies;   // Set of movies the user liked
    set<string> preferredGenres;  // Genres the user prefers

    // Constructor
    User(string n) : name(n) {}
};

// Movie Recommendation System
class MovieRecommendationSystem {
private:
    unordered_map<string, Movie*> movies;  // Hash map to store movie data
    unordered_map<string, User*> users;    // Hash map to store user data
    map<string, set<string>> userGraph;    // Graph connecting users to the movies they liked

public:
    // Add a new movie to the system
    void addMovie(string title, double rating, set<string> genres) {
        if (movies.find(title) == movies.end()) {
            movies[title] = new Movie(title, rating, 1, genres);
            cout << "Movie " << title << " added to the system.\n";
        } else {
            cout << "Movie already exists.\n";
        }
    }

    // Add a new user to the system
    void addUser(string name) {
        if (users.find(name) == users.end()) {
            users[name] = new User(name);
            cout << "User " << name << " added to the system.\n";
        } else {
            cout << "User already exists.\n";
        }
    }

    // User likes a movie
    void userLikesMovie(string userName, string movieTitle) {
        if (users.find(userName) != users.end() && movies.find(movieTitle) != movies.end()) {
            users[userName]->likedMovies.insert(movieTitle);
            userGraph[userName].insert(movieTitle);
            cout << userName << " liked the movie " << movieTitle << ".\n";
        } else {
            cout << "User or movie not found.\n";
        }
    }

    // User prefers a genre
    void userPrefersGenre(string userName, string genre) {
        if (users.find(userName) != users.end()) {
            users[userName]->preferredGenres.insert(genre);
            cout << userName << " prefers genre " << genre << ".\n";
        } else {
            cout << "User not found.\n";
        }
    }

    // Recommend movies based on user preferences
    void recommendMovies(string userName) {
        if (users.find(userName) == users.end()) {
            cout << "User not found.\n";
            return;
        }

        priority_queue<Movie*, vector<Movie*>, MovieComparator> pq;

        // Add movies to the priority queue based on the user's preferred genres
        for (auto& moviePair : movies) {
            Movie* movie = moviePair.second;

            // Check if the movie matches the user's preferred genres
            for (const string& genre : users[userName]->preferredGenres) {
                if (movie->genres.find(genre) != movie->genres.end()) {
                    pq.push(movie);
                    break;  // Add movie only once if it matches one of the preferred genres
                }
            }
        }

        // Recommend top 5 movies
        cout << "Top recommended movies for " << userName << ":\n";
        for (int i = 0; i < 5 && !pq.empty(); i++) {
            Movie* recommendedMovie = pq.top();
            pq.pop();
            cout << i + 1 << ". " << recommendedMovie->title << " (Rating: " << recommendedMovie->rating << ")\n";
        }
    }
};

// Helper function to get genres as a set
set<string> inputGenres() {
    set<string> genres;
    int n;
    cout << "Enter the number of genres: ";
    cin >> n;
    cin.ignore();  // To handle newline character after input

    for (int i = 0; i < n; i++) {
        string genre;
        cout << "Enter genre " << i + 1 << ": ";
        getline(cin, genre);
        genres.insert(genre);
    }

    return genres;
}

// Main function
int main() {
    MovieRecommendationSystem system;
    int choice;

    do {
        cout << "\nMovie Recommendation System Menu\n";
        cout << "1. Add Movie\n";
        cout << "2. Add User\n";
        cout << "3. User Likes Movie\n";
        cout << "4. User Prefers Genre\n";
        cout << "5. Recommend Movies\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();  // To handle newline character after input

        if (choice == 1) {
            string title;
            double rating;
            cout << "Enter movie title: ";
            getline(cin, title);
            cout << "Enter movie rating (out of 10): ";
            cin >> rating;
            cin.ignore();  // To handle newline character

            set<string> genres = inputGenres();
            system.addMovie(title, rating, genres);

        } else if (choice == 2) {
            string userName;
            cout << "Enter user name: ";
            getline(cin, userName);
            system.addUser(userName);

        } else if (choice == 3) {
            string userName, movieTitle;
            cout << "Enter user name: ";
            getline(cin, userName);
            cout << "Enter movie title: ";
            getline(cin, movieTitle);
            system.userLikesMovie(userName, movieTitle);

        } else if (choice == 4) {
            string userName, genre;
            cout << "Enter user name: ";
            getline(cin, userName);
            cout << "Enter preferred genre: ";
            getline(cin, genre);
            system.userPrefersGenre(userName, genre);

        } else if (choice == 5) {
            string userName;
            cout << "Enter user name: ";
            getline(cin, userName);
            system.recommendMovies(userName);

        } else if (choice == 6) {
            cout << "Exiting...\n";
        } else {
            cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 6);

    return 0;
}
